"""RAG knowledge-base chatbot."""
